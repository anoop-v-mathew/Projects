module.exports = {
  database: 'mongodb://vfc_db_user:vfc_db_user@ds117730.mlab.com:17730/vfc',
  secret: 'thunder'
}